export const BUILD_DEFAULTS = {
  apiBaseUrl: "https://refhub-api.netlify.app",
  appBaseUrl: "https://refhub.io",
  allowCustomUrls: false,
};
