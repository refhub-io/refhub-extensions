export const BUILD_DEFAULTS = {
  apiBaseUrl: "http://localhost:8888",
  appBaseUrl: "https://refhub.io",
  allowCustomUrls: true,
};
